import React, {useState} from 'react';

function GetUsers(){
const [usuarios,setUsuarios] = useState([]);

let get = async () => {
        const response = await fetch("http://127.0.0.1:4000/users/");
        const data = await response.json();
        setUsuarios(data);
        console.log(usuarios)
        return data;
    }
let salida = usuarios.map((item,index)=>{
    return (<div key={index}>{item.id} {item.name}</div>)
})
    return(<>
    <button onClick={()=>{get()}}>Get Users</button>
    <div>{salida}</div>
    </>)
}

export default GetUsers;