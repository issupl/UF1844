import React,{useState} from "react";

function GetMessages(props){

    const [messages,setMessages] = useState([]);
    const authToken = (id, secret) =>{
        // En autenticación Basic, usuario y contraseña se separan con ':'
        const authToken = `${id}:${secret}`;
        // Y se codifican en Base64
        const base64token = window.btoa(authToken);
        return `Basic ${base64token}`;
      }
   const authGet = async (token) => {
        const response = await fetch(
            "http://127.0.0.1:4000/messages/",
            { 
                headers: {
                    Authorization: authToken(props.elId,props.elPassword)
                }
            }
        );
        const data = await response.json();
        setMessages(data);
        console.log(data)
        return data;
    }

    let salida = messages.map((item,index)=>{
        return (<div key={index}>{item.source} {item.content}</div>)
    })


    return (<><button onClick={()=>{authGet()}}>Get Messages</button>
    <div>{salida}</div></>)

}

export default GetMessages;