import React, {useState} from 'react';
import FormEnvio from './FormEnvio/FormEnvio';
import GetMessages from './GetMesages/GetMessages';
import GetUsers from './GetUsers/GetUsers';

function App() {
  const [inputs, setInputs] = useState({});
  const [id,setId]=useState('');

  

const post = async (url, data) => {
  const response = await fetch(
      url,
      {
          method: 'POST',
          body: data,
          headers: {
              "Content-Type": "application/json",
          }
      }
  );
  const responseData = await response.json();
  return responseData;
}

  const handleChange = (event)=>{
    const name = event.target.name;
    const value = event.target.value;
    
    setInputs(values => ({...values, [name]: value}))
    console.log('entradas:',inputs)
  }
  const handleSubmit = async (event)=>{
    event.preventDefault();
    
    
   let respuesta = await post("http://127.0.0.1:4000/login/",JSON.stringify(inputs))
    setId(respuesta);
  }


  return (
    <><form onSubmit={handleSubmit}>
      <label htmlFor='userName'>Name</label>
      <input type="text" id='userName' value={inputs.name} name="userName" onChange={handleChange}/>
      <label htmlFor='password'>password</label>
      <input type="text" id='password' value={inputs.password} name="password" onChange={handleChange}/>

      <input type="submit" value="Submit"/>
    </form>

    <FormEnvio elId={id} elPassword={inputs.password}/>
    <GetUsers />
    <GetMessages elId={id} elPassword={inputs.password}/>
    </>
  );
}

export default App;
