import React,{useState} from "react";

function FormEnvio(props){
    const [contenido, setTextarea] = useState({})
    const authToken = (id, secret) =>{
        // En autenticación Basic, usuario y contraseña se separan con ':'
        const authToken = `${id}:${secret}`;
        // Y se codifican en Base64
        const base64token = window.btoa(authToken);
        return `Basic ${base64token}`;
      }
    const authPost = async (url, token, data) => {
        const response = await fetch(
            url,
            {
                method: "POST",
                body: data,
                headers: {
                    "Content-Type": "application/json",
                    Authorization: token
                }
            }
        );
        const responseData = await response.json();
        console.log('responseData: ',responseData)
        return responseData;
      }
    const handleChange1 = (event)=>{
        setTextarea(event.target.value)
    }
    const handleSubmit1 = async (event) =>{
        const mensage = new Object();
        mensage.content = contenido
        event.preventDefault();
    console.log('dato enviado: ',JSON.stringify(mensage),' authToken(props.elId,props.elPassword):',authToken(props.elId,props.elPassword))
    
        let respuesta = await authPost("http://127.0.0.1:4000/message/",authToken(props.elId,props.elPassword),JSON.stringify(mensage))
        console.log(respuesta)
    }

    return(<>
    <form onSubmit={handleSubmit1}>
        <textarea value={contenido} onChange={handleChange1}/>
        <input type="submit" value="Send message"/>
    </form>
    </>)
}

export default FormEnvio;